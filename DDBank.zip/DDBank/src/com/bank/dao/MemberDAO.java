package com.bank.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.bank.dto.MemberDTO;

public class MemberDAO {
   

   public int countAll() {
      Connection con = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;

      String sql = "";
      int count = 0;

      try {
         con = JdbcUtils.getConnection();
         
         // 3단계. SQL문을 가지는 문장객체 준비
         sql = "SELECT COUNT(*) FROM bankmember";
         pstmt = con.prepareStatement(sql);
         // 4단계. 문장객체로 SQL문 실행
         rs = pstmt.executeQuery();
         
         if (rs.next()) {
            count = rs.getInt(1);
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt, rs);
      }
      return count;
   } // countAll

   public void deleteAll() {
      Connection con = null;
      PreparedStatement pstmt = null;
      String sql = "";

      try {
         con = JdbcUtils.getConnection();
         // 3단계. SQL문을 가지는 문장객체 준비
         sql = "DELETE FROM bankmember";
         pstmt = con.prepareStatement(sql);
         // 4단계. 문장객체로 SQL문 실행
         pstmt.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt);
      }
   } // deleteAll
   
   
   public void addMember(MemberDTO memberDTO) {
      Connection con = null;
      PreparedStatement pstmt = null;
      String sql = "";

      try {
         con = JdbcUtils.getConnection();
         // 3단계. SQL문을 가지는 문장객체 준비
         sql  = "INSERT INTO bankmember (id, pwd, name, tel, email, address, accountnum) ";
         sql += "VALUES (?, ?, ?, ?, ?, ?, ?) ";
         
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1,memberDTO.getId());
         pstmt.setString(2,memberDTO.getPwd());
         pstmt.setString(3,memberDTO.getName());
         pstmt.setString(4,memberDTO.getTel());
         pstmt.setString(5,memberDTO.getEmail());
         pstmt.setString(6,memberDTO.getAddress());
         pstmt.setString(7,memberDTO.getAccountnum());
         
         // 4단계. 문장객체로 SQL문 실행
         pstmt.executeUpdate();
         System.out.println("insert 성공!");
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt);
      }
   } // addMember
   
   public List<MemberDTO> getMembers() {
      List<MemberDTO> list = new ArrayList<>();
      
      Connection con = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      String sql = "";
      
      try {
         con = JdbcUtils.getConnection();
         
         sql = "SELECT * FROM bankmember ORDER BY id";
         pstmt = con.prepareStatement(sql);
         
         rs = pstmt.executeQuery();
         
         while (rs.next()) {
            MemberDTO memberDTO=new MemberDTO();
            memberDTO.setId(rs.getString("id"));
            memberDTO.setPwd(rs.getString("pwd"));
            memberDTO.setName(rs.getString("name"));
            memberDTO.setTel(rs.getString("tel"));
            memberDTO.setEmail(rs.getString("email"));
            memberDTO.setAddress(rs.getString("address"));
            memberDTO.setAccountnum(rs.getString("accountnum"));
         
            list.add(memberDTO);
         } // while
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt, rs);
      }
      return list;
   } // getMembers
   
   
   public MemberDTO getMemberById(String id) {
      MemberDTO memberDTO = null;
      
      Connection con = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      String sql = "";
      
      try {
         con = JdbcUtils.getConnection();
         
         sql = "SELECT * FROM bankmember WHERE id = ? ";
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, id);
         
         rs = pstmt.executeQuery();
         
         if (rs.next()) {
            memberDTO = new MemberDTO();
            memberDTO.setId(rs.getString("id"));
            memberDTO.setPwd(rs.getString("pwd"));
            memberDTO.setName(rs.getString("name"));
            memberDTO.setTel(rs.getString("tel"));
            memberDTO.setEmail(rs.getString("email"));
            memberDTO.setAddress(rs.getString("address"));
            memberDTO.setAccountnum(rs.getString("accountnum"));
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt, rs);
      }
      return memberDTO;
   } // getMemberById
   
   
   
   public int getCountById(String id) {
      int count = 0;
      
      Connection con = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      String sql = "";
      
      try {
         con = JdbcUtils.getConnection();
         
         sql = "SELECT COUNT(*) FROM bankmember WHERE id = ? ";
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, id);
         
         rs = pstmt.executeQuery();
         
         if (rs.next()) {
            count = rs.getInt(1);
         }
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt, rs);
      }
      return count;
   } // getCountById
   
   
   public void updateMember(MemberDTO memberDTO) {
         Connection con = null;
         PreparedStatement pstmt = null;
         String sql = "";
         
         try {
            con = JdbcUtils.getConnection();
            
            sql  = "UPDATE bankmember ";
            sql += "SET name = ?, pwd = ?, tel =? , email =?, address= ? ,accountnum= ? ";
            sql += "WHERE id = ? ";
            
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, memberDTO.getName());
            pstmt.setString(2, memberDTO.getPwd());
            pstmt.setString(3, memberDTO.getTel());
            pstmt.setString(4, memberDTO.getEmail());
            pstmt.setString(5, memberDTO.getAddress());
            pstmt.setString(6, memberDTO.getAccountnum());
            pstmt.setString(7, memberDTO.getId());
            
            pstmt.executeUpdate();
         } catch (Exception e) {
            e.printStackTrace();
         } finally {
            JdbcUtils.close(con, pstmt);
         }
      } // updateMember
   
   
   public void deleteById(String id) {
      Connection con = null;
      PreparedStatement pstmt = null;
      String sql = "";
      
      try {
         con = JdbcUtils.getConnection();
         
         sql = "DELETE FROM bankmember WHERE id = ? ";
         
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1, id);
         
         pstmt.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt);
      }
   } // deleteById
   

   public static void main(String[] args) {
      

   } // main

}