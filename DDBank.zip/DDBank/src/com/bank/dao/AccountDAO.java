package com.bank.dao;

import java.sql.*;

import com.bank.dto.AccountDTO;

public class AccountDAO {
   
   public void addAccount(AccountDTO accountDTO) {
      Connection con = null;
      PreparedStatement pstmt = null;
      String sql = "";

      try {
         con = JdbcUtils.getConnection();

         sql  = "INSERT INTO bankaccount (name, anum, deposit, tel, email, apwd) ";
         sql += "VALUES (?, ?, ?, ?, ?, ?) ";
         
         pstmt = con.prepareStatement(sql);
         pstmt.setString(1,accountDTO.getName());
         pstmt.setString(2,accountDTO.getAnum());
         pstmt.setString(3,accountDTO.getDeposit());
         pstmt.setString(4,accountDTO.getTel());
         pstmt.setString(5,accountDTO.getEmail());
         pstmt.setString(6,accountDTO.getApwd());
         
         pstmt.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         JdbcUtils.close(con, pstmt);
      }
   } // addAccount

}