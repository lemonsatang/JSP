package com.bank.openboard;

import java.io.File;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;

public class DeleteProAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("DeleteProAction...");

		// 파라미터값  pageNum   num   pwd  가져오기
		String pageNum = request.getParameter("pageNum");
		int num = Integer.parseInt(request.getParameter("num"));
		String pwd = request.getParameter("pwd");

		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();

		// 본인글 확인용 패스워드 비교하기
		boolean isCorrect = dao.isPasswdCorrect(num, pwd);

		// 글 패스워드 일치하지 않을때
		if (!isCorrect) { // isCorrect == false
			response.setContentType("");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("	alert('글 패스워드 틀림. 다시 입력하세요.');");
			out.println("	history.back();");
			out.println("</script>");
			out.close();
			return null;
		}

		// 글 패스워드 일치할때
		// 글번호에 해당하는 글내용 가져오기(첨부파일 정보 확인을 위해서)
		OpenboardDTO vo = dao.getOpenboardByNum(num);
		// 첨부파일 존재여부 확인해서 있으면 삭제하기
		String filename = vo.getFilename();
		if (filename != null) { // 첨부파일이 있으면
			// 실제 업로드되어있는 경로 구하기
			ServletContext application = request.getServletContext(); // application
			String realPath = application.getRealPath("/upload"); // 업로드 경로
			// File 객체 준비
			File file = new File(realPath, filename);
			if (file.exists()) { // 해당 경로에 파일이 존재하는지 확인
				file.delete(); // 파일 삭제하기
			}
		}


		// DB 테이블 글내용 삭제하기
		dao.deleteByNum(num);

		// 글목록 페이지로 리다이렉트 시키기
		//response.sendRedirect("openboard.jsp?pageNum=" + pageNum);
		
		return "redirect:/openboard.do?pageNum=" +pageNum;
	}

}
