package com.bank.openboard;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;
import com.bank.dto.PageDTO;



public class OpenboardAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("OpenboardAction......");
		
		// pageNum 파라미터값 가져오기
		String strPageNum = request.getParameter("pageNum");
		// strPageNum 값이 null이면 "1"로 수정하기 (디폴트값을 "1"로 설정)
		strPageNum = (strPageNum == null) ? "1" : strPageNum ;
		// 문자열 페이지번호를 정수형으로 변환하기
		int pageNum = Integer.parseInt(strPageNum);

		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();

		int totalCount = dao.countAll(); // 전체 글갯수

		
		// ==========================================
		// 한 페이지에 해당하는 글목록 리스트 구하기 
		// ==========================================
		int pageSize = 10;
		// 시작행 인덱스번호 구하기 수식
		int startRow = (pageNum-1) * pageSize;

		// 글목록 가져오기
		List<OpenboardDTO> list = dao.getOpenboards(startRow, pageSize);
		
		
		// ==========================================
		// 페이지블록 관련정보 구하기 
		// ==========================================
		PageDTO pageDto = new PageDTO();
		pageDto.setTotalCount(totalCount);
		
		if (totalCount > 0) {
			// 총 페이지 갯수 구하기
			// 글50개. 한페이지에 보여줄 글갯수 10개. 50/10 -> 5 페이지
			// 글55개. 한페이지에 보여줄 글갯수 10개. 55/10 -> 5 + 1(나머지 있으면) -> 6페이지
			//int pageCount = (totalCount / pageSize) + ( totalCount % pageSize == 0 ? 0 : 1 );
			int pageCount = (int) Math.ceil((double) totalCount / pageSize); 
			
			// 화면에 보여줄 페이지번호의 갯수 설정
			int pageBlock = 10;
			
			// 페이지블록의 시작페이지 번호 구하기
			// 1~10    11~20     21~30
			
			//          시작페이지번호
			//  1~10 ->  1
			// 11~20 -> 11
			// 21~30 -> 21
			// 31~40 -> 31
			
			// 페이지블록의 시작페이지번호 구하기 수식
			int startPage = ((pageNum / pageBlock) - (pageNum % pageBlock == 0 ? 1 : 0)) * pageBlock + 1;
			// 페이지블록의 끝페이지번호 구하기
			int endPage = startPage + pageBlock - 1;
			if (endPage > pageCount) {
				endPage = pageCount;
			}
			
			// page 블록 관련정보를  DTO에 저장
			pageDto.setPageCount(pageCount);
			pageDto.setPageBlock(pageBlock);
			pageDto.setStartPage(startPage);
			pageDto.setEndPage(endPage);
					
		} // if
		
		
		// 뷰(jsp)에서 사용할 데이터를 request 영역객체에 저장
		request.setAttribute("list", list);
		request.setAttribute("pageDto", pageDto);
		request.setAttribute("pageNum", pageNum);
		
		
		return "openboard/openboard";
	}

}
