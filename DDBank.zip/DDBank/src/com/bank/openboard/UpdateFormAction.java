package com.bank.openboard;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;

public class UpdateFormAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("UpdateFormAction...");
		
		// 파라미터값  pageNum  num  passwd  가져오기
		String pageNum = request.getParameter("pageNum");
		int num = Integer.parseInt(request.getParameter("num"));
		String pwd = request.getParameter("pwd");

		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();

		// 글번호에 해당하는 패스워드 비교하기
		boolean isCorrect = dao.isPasswdCorrect(num, pwd);

		// 패스워가 불일치하면 "글 패스워드가 틀림"  뒤로가기
		if (!isCorrect) {
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('글 패스워드가 틀립니다. 다시 입력하세요.');");
			out.println("history.back();");
			out.println("</script>");
			out.close();
			return null;
		}

		// 글번호에 해당하는 글정보 한개 가져오기
		OpenboardDTO vo = dao.getOpenboardByNum(num);

		// request 영역 객체에 저장
		request.setAttribute("board", vo);
		request.setAttribute("pageNum", pageNum);
		
		return "openboard/updateForm";
	}

}
