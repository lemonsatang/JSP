package com.bank.openboard;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;


public class DeleteFormAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("DeleteFromAction..");
		
		// 파라미터값  num  pageNum  가져오기
		//String num = request.getParameter("num");
		//String pageNum = request.getParameter("pageNum");
		
		// request 영역객체에 저장
		//request.setAttribute("num", num);
		//request.setAttribute("pageNum", pageNum);
		
		return "openboard/deleteForm";
	}

}
