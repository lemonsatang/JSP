package com.bank.openboard;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;

public class UpdateCheckFormAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("UpdateCheckFormAction...");
		
		// num pageNum 파라미터값 가져오기
		String num = request.getParameter("num");
		String pageNum = request.getParameter("pageNum");
		
		//request 영역 객체에 저장하기
		request.setAttribute("num", num);
		request.setAttribute("pageNum", pageNum);
		
		return "openboard/updateCheckForm";
	}

}
