package com.bank.openboard;

import java.sql.Timestamp;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class ReplyWriteProAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
				ServletContext application = request.getServletContext();
				
				String realPath = application.getRealPath("/upload");

				int maxSize =1024 * 1024 * 50; // 50MB 제한
	
				MultipartRequest multi = new MultipartRequest(
						request, realPath, maxSize, "utf-8", new DefaultFileRenamePolicy());


				OpenboardDAO dao = new OpenboardDAO();
				OpenboardDTO vo = new OpenboardDTO();
				
				int ref=Integer.parseInt(multi.getParameter("reRef"));
				int lev=Integer.parseInt(multi.getParameter("reLev"));
				int seq=Integer.parseInt(multi.getParameter("reSeq"));
				
				vo.setReRef(ref);
				vo.setReSeq(seq);
				dao.updateReSeqInReRef(ref, seq);
				
				int num = dao.getNextNum();
				vo.setNum(num);
				vo.setName(multi.getParameter("name"));
				vo.setPwd(multi.getParameter("pwd"));
				vo.setSubject(multi.getParameter("subject"));
				vo.setContent(multi.getParameter("content"));
				vo.setReadcount(0); // 조회수 0
				vo.setRegDate(new Timestamp(System.currentTimeMillis()));
				vo.setIp(request.getRemoteAddr()); // 작성자 IP주소 문자열
				vo.setReRef(ref); 
				vo.setReLev(lev+1); 
				vo.setReSeq(seq+1); 

				String originalFilename = multi.getOriginalFileName("filename");
				System.out.println("원본 파일명 = " + originalFilename);
				String realFilename = multi.getFilesystemName("filename");
				System.out.println("실제 파일명 = " + realFilename);
				vo.setFilename(realFilename);

				System.out.println(vo);
				
				// 글 inset 하기
				dao.add(vo);
				
				return "redirect:/openboard.do";
	}

}
