package com.bank.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IndexAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("IndexAction......");
		// 실행할 jsp페이지인  index.jsp의
		// 웹서버 내부 경로정보를 문자열로 리턴함
		return "index";
	}

}