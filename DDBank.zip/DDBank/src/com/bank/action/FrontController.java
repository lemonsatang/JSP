package com.bank.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
*웹프로그램이 동작하는 과정
 웹서버 톰캣(WAS)가 기동됨 -> 사용자가 jsp나 서블릿 실행경로 요청
 -> jsp라면 서블릿 클래스로 변환 후 객체 생성해서 별도의 스레드로 실행
*/

@WebServlet(urlPatterns = "*.do", loadOnStartup = 1)
public class FrontController extends HttpServlet {
	
	@Override
	public void init(ServletConfig config) throws ServletException{
		// 웹프로그램 당 유지되는 맵 자료구조 객체
		ServletContext application = config.getServletContext();
		application.setAttribute("aa", "AA");
	}
	
	@Override
	public void destroy() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 요청주소
		// http://127.0.0.1:80/funweb/index.do
		// 또는
		// http://127.0.0.1:80/index.do
		
		// 1단계) 명령어 command 구하기
		
		// URI 주소 가져오기
		String requestURI = request.getRequestURI();
		System.out.println("URI주소 : " + requestURI);
		// URI주소 : /funweb/index.do
		
		// 프로젝트 이름경로 가져오기
		String contextPath = request.getContextPath();
		System.out.println("contextPath : " + contextPath);
		// contextPath : /funweb
		
		// 요청 명령어 구하기
		String command = requestURI.substring(contextPath.length());
		command = command.substring(0, command.indexOf(".do")); // ".do" 제거
		System.out.println("command : " + command);
		
		
		// 2단계) 명령어 작업 실행하기
		ActionFactory actionFactory = ActionFactory.getInstance();
		Action action = null;
		String strView = null;
		
		// 명령어 command를 처리하는 Action타입 객체 가져오기
		action = actionFactory.getAction(command);
		
		if(action == null) {
			System.out.println(command + "를 처리하는 Action 객체가 없습니다.");
			return;
		}
		
		// Action타입 객체 실행하기
		try {
			strView = action.execute(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		// 3단계) 화면응답 또는 이동하기
		
		// 이동정보가 없으면(null이면) 3단계 작업 수행 안함
		if(strView == null) {
			System.out.println("화면이동 정보 없음");
			return;
		}
		
		// 이동정보가 있으면 redirect: 접두사 유무에 따라
		// 리다이렉트 방식으로 이동하거나 디스패치 방식으로 이동시킴
		if(strView.startsWith("redirect:")) {
			String redirectPath = strView.substring("redirect:".length());
			response.sendRedirect(redirectPath);
		} else {
			// 디스패치 방식으로 jsp를 서버에서 바로 실행
			String jspPath = "/WEB-INF/views/" + strView + ".jsp";
			
			RequestDispatcher dispatcher = request.getRequestDispatcher(jspPath);
			dispatcher.forward(request, response);
		}
			
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8"); // 한글처리
		doGet(request, response);
	}

}