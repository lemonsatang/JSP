package com.bank.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Action {
	// 명령어에 따라서 request, response를 받아서 처리 후
	// 응답으로 실행할 jsp 경로 정보 또는 리다이렉트 경로 정보를 String으로 리턴해줌
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception;
}