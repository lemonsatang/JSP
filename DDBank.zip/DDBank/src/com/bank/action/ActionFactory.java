package com.bank.action;

import java.util.HashMap;
import java.util.Map;

import com.bank.company.HistoryAction;
import com.bank.company.WelcomeAction;
import com.bank.member.AdminLoginAction;
import com.bank.member.AdminLoginProAction;
import com.bank.member.AdminLogoutAction;
import com.bank.member.AdminReplyAction;
import com.bank.member.AdminReplyFormAction;
import com.bank.member.AdminUpdateAction;
import com.bank.member.AdminUpdateFormAction;
import com.bank.member.AdminWriteAction;
import com.bank.member.AdminWriteFormAction;
import com.bank.member.JoinAction;
import com.bank.member.JoinIdDupCheckAction;
import com.bank.member.JoinProAction;
import com.bank.member.LoginAction;
import com.bank.member.LoginProAction;
import com.bank.member.LogoutAction;
import com.bank.member.MDelAllAction;
import com.bank.member.MUpdateProAction;
import com.bank.member.MdeleteAction;
import com.bank.member.MdetailAction;
import com.bank.member.MemberListAction;
import com.bank.member.AdminBoardAction;
import com.bank.member.AdminContentAction;
import com.bank.member.AdminDeleteAction;
import com.bank.member.AdminDeleteAllAction;
import com.bank.mypage.MypageAction;
import com.bank.mypage.UpdateMypageAction;
import com.bank.mypage.UpdateMypageProAction;
import com.bank.openboard.ContentAction;
import com.bank.openboard.DeleteFormAction;
import com.bank.openboard.DeleteProAction;
import com.bank.openboard.OpenboardAction;
import com.bank.openboard.ReplyWriteFormAction;
import com.bank.openboard.ReplyWriteProAction;
import com.bank.openboard.UpdateCheckFormAction;
import com.bank.openboard.UpdateFormAction;
import com.bank.openboard.UpdateProAction;
import com.bank.openboard.WriteFormAction;
import com.bank.openboard.WriteProAction;
import com.bank.personal.TransferFormAction;
import com.bank.personal.TransferProAction;

public class ActionFactory {
	// 싱글톤 패턴 : 프로그램 시작부터 종료까지 객체 한개만 사용하는 패턴
	// static 변수 = 클래스 변수
	private static ActionFactory instance = new ActionFactory();
	
	public static ActionFactory getInstance() {
		return instance;
	}

	private Map<String, Action> map = new HashMap<>();
	
	private ActionFactory() {
		map.put("/index", new IndexAction());
		
		map.put("/join", new JoinAction());
		map.put("/joinPro", new JoinProAction());
		map.put("/login", new LoginAction());
		map.put("/loginPro", new LoginProAction());
		map.put("/logout", new LogoutAction());
		map.put("/joinIdDupCheck", new JoinIdDupCheckAction());
		
		map.put("/adminLogin", new AdminLoginAction());
		map.put("/adminLoginPro", new AdminLoginProAction());
		map.put("/adminLogout", new AdminLogoutAction());
		map.put("/adminBoard", new AdminBoardAction());
		map.put("/adminWriteForm", new AdminWriteFormAction());
		map.put("/adminWrite", new AdminWriteAction());
		map.put("/adminContent", new AdminContentAction());
		map.put("/adminDelete", new AdminDeleteAction());
		map.put("/adminDeleteAll", new AdminDeleteAllAction());
		map.put("/adminUpdateForm", new AdminUpdateFormAction());
		map.put("/adminUpdate", new AdminUpdateAction());
		map.put("/adminReplyForm", new AdminReplyFormAction());
		map.put("/adminReply", new AdminReplyAction());
		
		map.put("/memberList", new MemberListAction());
		map.put("/MDelAllAction",new MDelAllAction());
		map.put("/Mdetail", new MdetailAction());
		map.put("/MUpdatePro", new MUpdateProAction());
		map.put("/Mdelete", new MdeleteAction());
		
		map.put("/mypage", new MypageAction());
		map.put("/updateMypage", new UpdateMypageAction());
		map.put("/updateMypagePro", new UpdateMypageProAction());
		
		map.put("/history", new HistoryAction());
		map.put("/welcome", new WelcomeAction());
		
		map.put("/transfer", new TransferFormAction());
		map.put("/transferPro", new TransferProAction());
		
		map.put("/openboard", new OpenboardAction());
		map.put("/content", new ContentAction());
		map.put("/writeForm", new WriteFormAction());
		map.put("/writePro", new WriteProAction());
		map.put("/deleteForm", new DeleteFormAction());
		map.put("/deletePro", new DeleteProAction());
		map.put("/updateCheckForm", new UpdateCheckFormAction());
		map.put("/updateForm", new UpdateFormAction());
		map.put("/updatePro", new UpdateProAction());
		map.put("/replyWriteForm", new ReplyWriteFormAction());
		map.put("/replyWritePro", new ReplyWriteProAction());
	} // 생성자
	
	public Action getAction(String command) {
		Action action = null;
		
		action = map.get(command);
		return action;
	}
	
}