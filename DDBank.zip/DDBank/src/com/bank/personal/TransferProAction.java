package com.bank.personal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.AccountDAO;
import com.bank.dto.AccountDTO;

public class TransferProAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("TransferProAction......");

		// DTO 객체 준비
		AccountDTO dto = new AccountDTO();

		// 파라미터값을 찾아서 DTO객체에 저장
		dto.setName(request.getParameter("name"));
		dto.setAnum(request.getParameter("anum"));
		dto.setDeposit(request.getParameter("deposit"));
		dto.setTel(request.getParameter("tel"));
		dto.setEmail(request.getParameter("email"));
		dto.setApwd(request.getParameter("apwd"));

		// DAO 객체 준비
		AccountDAO dao = new AccountDAO();
		
		dao.addAccount(dto);
		
		return "redirect:/index.do";
	}

}