package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;
import com.bank.dto.MemberDTO;

public class MUpdateProAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		MemberDTO memberDTO=new MemberDTO();
		
		memberDTO.setId(request.getParameter("id"));
	    memberDTO.setPwd(request.getParameter("pwd"));
	    memberDTO.setName(request.getParameter("name"));
	    memberDTO.setTel(request.getParameter("tel"));
	    memberDTO.setEmail(request.getParameter("email"));
	    memberDTO.setAddress(request.getParameter("address"));
	    memberDTO.setAccountnum(request.getParameter("accountnum"));
	    
	    MemberDAO memberDAO=new MemberDAO();
	    
	    memberDAO.updateMember(memberDTO);
	    
		return "redirect:/memberList.do";
	}

}
