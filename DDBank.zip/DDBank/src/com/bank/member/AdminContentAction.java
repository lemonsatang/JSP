package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;

public class AdminContentAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("ContentAction...");
		
		// num  pageNum   파라미터값 가져오기
		int num = Integer.parseInt(request.getParameter("num"));
		String pageNum = request.getParameter("pageNum");

		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();

		// 글번호 num에 해당하는 글의 조회수를 1 증가시키기
		dao.updateReadcountByNum(num);

		// 글번호 num에 해당하는 글한개를 VO로 가져오기
		OpenboardDTO dto = dao.getOpenboardByNum(num);
		
		// 첨부파일 존재유무
		boolean hasFile = (dto.getFilename() != null ) ? true : false;
		
		boolean isImage = false;
		if(hasFile) { //hasFile == true
			isImage = isImage(dto.getFilename());
		}
		
		// request 영역객체에 vo객체를 저장
		request.setAttribute("board", dto);
		request.setAttribute("hasFile", hasFile);
		request.setAttribute("isImage", isImage);
		request.setAttribute("pageNum", pageNum);
		
		
		return "member/adminContent";
	} //execute

	int max = 100;

	//이미지 파일이면(확장자가 jpg, jpeg, gif, png) img태그로 보여주기
	// 이미지 파일이 아니면 다운로드 링크걸기
	boolean isImage(String filename) {
		boolean isImage = false;
		
		int index = filename.lastIndexOf(".");
		String ext = filename.substring(index + 1); // 확장자 문자열
		
		if (ext.equalsIgnoreCase("jpg") 
				|| ext.equalsIgnoreCase("jpeg")
				|| ext.equalsIgnoreCase("gif")
				|| ext.equalsIgnoreCase("png")) {
			isImage = true;
		} else {
			isImage = false;
		}
		return isImage;
	}
}
