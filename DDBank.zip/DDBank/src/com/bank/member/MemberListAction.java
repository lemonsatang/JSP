package com.bank.member;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;
import com.bank.dto.MemberDTO;

public class MemberListAction implements Action {
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("AdminLoginAction......");
		
		MemberDAO memberDAO= new MemberDAO();
		List<MemberDTO> memberDTO = memberDAO.getMembers();
		int count = memberDAO.countAll();
		
		System.out.println(memberDTO);
		
		request.setAttribute("memberlist", memberDTO);
		request.setAttribute("count", count);
		
		return "member/memberList";
	}

}
