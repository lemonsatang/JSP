package com.bank.member;

import java.io.PrintWriter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bank.action.Action;

public class LogoutAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("LogoutAction......");
		
		// 세션값 초기화(세션에 저장된 모든정보 삭제)
		HttpSession session = request.getSession();
		session.invalidate();
		
		// 로그인 상태유지용 쿠키가 존재하면 삭제처리
		Cookie[] cookies = request.getCookies();

		if (cookies != null) {
			for (Cookie cookie : cookies) {
				// 쿠키이름이 "id"인 쿠키를 삭제하도록 유효기간을 0으로 설정
				if (cookie.getName().equals("id")) {
					cookie.setMaxAge(0); // 쿠키삭제 의도로 유효기간 0 설정
					cookie.setPath("/"); // 경로설정 유의!
					response.addCookie(cookie);
				}
			} // for
		}
		
		// "로그아웃됨" index.do로 리다이렉트 이동
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<script>");
		out.println("alert('로그아웃 되었습니다');");
		out.println("location.href = '/index.do';");
		out.println("</script>");
		out.close(); // 닫을 때 버퍼 비움
		
		return null;
	}

}