package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;

public class MdeleteAction implements Action{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String id=request.getParameter("id");
		System.out.println(id);
		MemberDAO memberDAO = new MemberDAO();
		memberDAO.deleteById(id);
		
		return "redirect:/memberList.do";
	}
	
	

}
