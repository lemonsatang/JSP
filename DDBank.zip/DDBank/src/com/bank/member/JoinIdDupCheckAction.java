package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;

public class JoinIdDupCheckAction implements Action {
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("JoinIdDupCheckAction......");
		
		// 파라미터값 "id" 가져오기
		String id = request.getParameter("id");

		//DAO 객체 준비
		MemberDAO memberDao = new MemberDAO();
		// 아이디 중복인지 확인하기
		int count = memberDao.getCountById(id);
		// count값이 1이면 아이디 중복, 0이면 중복아님
		boolean isIdDup = (count == 1) ? true : false;
		
		// JSP 내장 영역객체 4개 (톰캣이 관리함)
		// 	       서로 다른 Scope(객체가 유지되는 범위)를 가짐
		// 1) application : 웹 프로그램 당 1개 객체 유지
		// 2) session : 클라이언트(사용자) 당 1개 객체 유지
		// 3) request : 클라이언트 요청 당 1개 객체 유지
		//				요청이 발생할 때마다 객체 생성되고
		//				응답을 주고나면 바로 삭제됨
		// 4) page : JSP 한 페이지 당 1개 객체 유지
		//			 JSP 페이지 처리가 끝나면 바로 삭제됨
		
		// JSP 영역객체 수명주기 (큰 순으로 나열)
		// application > session > request > page
		
		// 데이터를 request 영역객체에 저장
		request.setAttribute("isIdDup", isIdDup);
		request.setAttribute("id", id);
		
		// 디스패치 방식으로 jsp 실행 시
		// 현재 request 객체가 그대로 전달됨
		return "member/joinIdDupCheck";
	}

}