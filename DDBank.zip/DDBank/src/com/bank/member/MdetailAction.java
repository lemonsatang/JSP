package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;
import com.bank.dto.MemberDTO;

public class MdetailAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("MdetailAction..");
		
		String id=request.getParameter("id");
		MemberDAO memberDAO = new MemberDAO();
		MemberDTO memberDTO = memberDAO.getMemberById(id);
		System.out.println(memberDTO);
		request.setAttribute("dto", memberDTO);
		return "member/memberDetail";
	}

}
