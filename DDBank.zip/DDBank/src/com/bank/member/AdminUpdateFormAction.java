package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;

public class AdminUpdateFormAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("AdminUpdateFormAction...");
		
		// 파라미터값  pageNum  num  passwd  가져오기
		String pageNum = request.getParameter("pageNum");
		int num = Integer.parseInt(request.getParameter("num"));

		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();

		// 글번호에 해당하는 글정보 한개 가져오기
		OpenboardDTO dto = dao.getOpenboardByNum(num);

		// request 영역 객체에 저장
		request.setAttribute("board", dto);
		request.setAttribute("pageNum", pageNum);
		
		return "member/adminUpdate";
	}

}