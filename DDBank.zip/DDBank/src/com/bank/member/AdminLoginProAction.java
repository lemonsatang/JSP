package com.bank.member;

import java.io.PrintWriter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bank.action.Action;
import com.bank.dao.AdminDAO;

public class AdminLoginProAction implements Action {
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("AdminLoginProAction......");
		
		// id pwd keepLogin 파라미터값 가져오기
		String admin_id = request.getParameter("admin_id");
		String admin_pwd = request.getParameter("admin_pwd");
		String strKeepLogin = request.getParameter("keepLogin");

		// 체크박스는 체크 안하면 null을 리턴함
		boolean keepLogin = false;
		if(strKeepLogin != null) {
			keepLogin = Boolean.parseBoolean(strKeepLogin); // "true" -> true
		}
		
		// DAO 객체 준비
		AdminDAO adminDAO = new AdminDAO();
		// id에 해당하는 DTO객체 리턴
		boolean adminDTO = adminDAO.adminCheck(admin_id, admin_pwd);
		
		if(adminDTO == false) {
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('관리자가 아닙니다.');");
			out.println("history.back();");
			out.println("</script>");
			out.close(); // 닫을 때 자동으로 버퍼 비움
			return null;
		}
		
		// 아이디, 패스워드 모두 일치할때(로그인 성공일때)
		// 세션객체 참조 가져오기
		HttpSession session = request.getSession();
		
		// 세션은 사용자 한명당 유지되는 일종의 자료구조 맵 객체
		// 로그인 처리. 세션에 로그인 확인용 데이터 저장.
		session.setAttribute("admin_id", admin_id);
		
		// 로그인 상태유지 원하면 쿠키 생성 후 응답주기
		if (keepLogin) { // keepLogin == true
			Cookie cookie = new Cookie("admin_id", admin_id);
			cookie.setMaxAge(60 * 10); // 쿠키 유효기간. 초단위 설정. 10분
			cookie.setPath("/"); // 쿠키생성 기준경로 설정
			
			response.addCookie(cookie);
		}
		
		// 로그인 성공하면 index 화면으로 리다이렉트
		return "redirect:/index.do";
	}
	
}