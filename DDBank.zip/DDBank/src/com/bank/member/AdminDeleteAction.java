package com.bank.member;

import java.io.File;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;

public class AdminDeleteAction implements Action {
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("AdminDeleteAction...");

		// 파라미터값  pageNum num pwd 가져오기
		String pageNum = request.getParameter("pageNum");
		int num = Integer.parseInt(request.getParameter("num"));

		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();
		
		OpenboardDTO dto = dao.getOpenboardByNum(num);
		// 첨부파일 존재여부 확인해서 있으면 삭제하기
		String filename = dto.getFilename();
		if (filename != null) { // 첨부파일이 있으면
			// 실제 업로드되어있는 경로 구하기
			ServletContext application = request.getServletContext(); // application
			String realPath = application.getRealPath("/upload"); // 업로드 경로
			// File 객체 준비
			File file = new File(realPath, filename);
			if (file.exists()) { // 해당 경로에 파일이 존재하는지 확인
				file.delete(); // 파일 삭제하기
			}
		}

		// DB 테이블 글내용 삭제하기
		dao.deleteByNum(num);

		// 글목록 페이지로 리다이렉트 시키기
		//response.sendRedirect("openboard.jsp?pageNum=" + pageNum);
		
		return "redirect:/adminBoard.do?pageNum="+pageNum;
	}
	
}