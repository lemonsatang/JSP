package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;

public class AdminDeleteAllAction implements Action {
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("AdminAllDeleteAction......");

		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();

		// DB 테이블 글내용 삭제하기
		dao.deleteAll();
		
		return "redirect: adminBoard.do";
	}
	
}