package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;

public class MDelAllAction implements Action {
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		MemberDAO memberDAO = new MemberDAO();
		memberDAO.deleteAll();
		
		return "redirect:/memberList.do";
	}

}
