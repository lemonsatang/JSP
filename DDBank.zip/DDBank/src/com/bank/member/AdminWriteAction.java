package com.bank.member;

import java.sql.Timestamp;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.OpenboardDAO;
import com.bank.dto.OpenboardDTO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class AdminWriteAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 파일 업로드 라이브러리로 cos 라이브러리 사용함
		// cos 라이브러리는 업로드부터 수행하도록 사용방식이 제약되어있음.

		// MultipartRequest 생성자 호출에서 파일 업로드가 수행 완료됨.

		// MultipartRequest 생성자 인자 5개
		// 1 request
		// 2 uplodad 폴더 생성하고 물리적 경로 지정
		
		// application 객체 참조 가져오기
		ServletContext application = request.getServletContext();
		
		String realPath = application.getRealPath("/upload");
		System.out.println("realPath = " + realPath);
		// 3 파일업로드 최대크기 제한 (바이트 단위)
		int maxSize =1024 * 1024 * 50; // 50MB 제한
		// 4 한글처리(utf-8 유니코드 적용)
		// 5 파일 이름이 중복일 경우 -> 파일 이름 변경 규칙을 가진 객체
		MultipartRequest multi = new MultipartRequest(
				request, realPath, maxSize, "utf-8", new DefaultFileRenamePolicy());


		// DAO 객체 준비
		OpenboardDAO dao = new OpenboardDAO();

		//DB 테이블에 insert할 글정보를 vo객체로 준비
		OpenboardDTO vo = new OpenboardDTO();

		// 주 글정보를 vo에 설정
		int num = dao.getNextNum();
		vo.setNum(num);
		vo.setName(multi.getParameter("name"));
		vo.setPwd(multi.getParameter("pwd"));
		vo.setSubject(multi.getParameter("subject"));
		vo.setContent(multi.getParameter("content"));
		vo.setReadcount(0); // 조회수 0
		vo.setRegDate(new Timestamp(System.currentTimeMillis()));
		vo.setIp(request.getRemoteAddr()); // 작성자 IP주소 문자열
		vo.setReRef(num); //주 글은 글그룹 번호와 글번호가 동일함
		vo.setReLev(0); //주 글은 들여쓰기 레벨이 0( 들여쓰기 안함)
		vo.setReSeq(0); //주글은 같은 글그룹 내에서 첫번째 순서

		// 원본 파일명
		String originalFilename = multi.getOriginalFileName("filename");
		System.out.println("원본 파일명 = " + originalFilename);
		// 업로드한 실제 파일명
		String realFilename = multi.getFilesystemName("filename");
		System.out.println("실제 파일명 = " + realFilename);
		vo.setFilename(realFilename);

		// 글 inset 하기
		dao.add(vo);

		// 글목록 openboard.jsp 로 이동
		//response.sendRedirect("openboard.jsp");
		
		return "redirect:/adminBoard.do";
	}

}
