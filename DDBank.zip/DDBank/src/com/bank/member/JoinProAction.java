package com.bank.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;
import com.bank.dto.MemberDTO;

public class JoinProAction implements Action {

   @Override
   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
	  System.out.println("JoinProAction......");
	  
	  // DTO 객체 준비
      MemberDTO memberDTO = new MemberDTO();
      
      // 파라미터값을 찾아서 DTO객체에 저장
      memberDTO.setId(request.getParameter("id"));
      memberDTO.setPwd(request.getParameter("pwd"));
      memberDTO.setName(request.getParameter("name"));
      memberDTO.setTel(request.getParameter("tel"));
      memberDTO.setEmail(request.getParameter("email"));
      memberDTO.setAddress(request.getParameter("address"));
      memberDTO.setAccountnum(request.getParameter("accountnum"));
      
      // DAO 객체 준비
      MemberDAO memberDAO = new MemberDAO();
      
      memberDAO.addMember(memberDTO);
      
      return "redirect:/login.do";
   }

}