package com.bank.mypage;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.action.Action;
import com.bank.dao.MemberDAO;
import com.bank.dto.MemberDTO;

public class MypageAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String id = request.getParameter("id");
		
		MemberDAO dao = new MemberDAO();
		
		MemberDTO dto = dao.getMemberById(id);
		
		request.setAttribute("board", dto);
		
		return "mypage/mypage";
	}
	
}