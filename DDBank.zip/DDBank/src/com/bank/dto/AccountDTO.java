package com.bank.dto;

public class AccountDTO {
	private int totalCount; //전체 글 갯수
	private String name;
	private String anum; //계좌번호
	private String deposit; //입금
	private String tel;
	private String email;
	private String apwd; //계좌비번
	
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAnum() {
		return anum;
	}
	public void setAnum(String anum) {
		this.anum = anum;
	}
	public String getDeposit() {
		return deposit;
	}
	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getApwd() {
		return apwd;
	}
	public void setApwd(String apwd) {
		this.apwd = apwd;
	}
	
	@Override
	public String toString() {
		return "AccountDTO [totalCount=" + totalCount + ", name=" + name + ", anum=" + anum + ", deposit=" + deposit
				+ ", tel=" + tel + ", email=" + email + ", apwd=" + apwd + "]";
	}
}